# LangVocab Hub - Multi-Language Vocabulary Learning App

## Overview
A web app for learning vocabulary in any language. Users can login, save their own vocab lists, use Google Translate integration for translations. Built with Next.js, planned to migrate to mobile apps later.

## Features (Phase 1 - Basic Structure)
- Multi-language support (not Thai-specific)
- User authentication (to be added)
- Vocab saving (local for now, later DB)
- Simple UI with language selector

## Tech Stack
- Next.js 16 + TypeScript + Tailwind
- Future: Supabase for auth/DB, Google Translate API

## Project Plan Phases
1. **Basic Web Structure & UI** (Current)
2. User Auth & Data Persistence
3. Google Translate Integration
4. Advanced Features (Quizzes, etc.)
5. Mobile App Transfer (React Native)

## Getting Started
```bash
npm install
npm run dev
```


## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
