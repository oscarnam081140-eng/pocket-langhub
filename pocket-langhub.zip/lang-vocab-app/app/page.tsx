'use client';

import React, { useState } from 'react';

interface VocabItem {
  id: number;
  word: string;
  translation: string;
  language: string;
  example?: string;
}

const languages = [
  { code: 'th', name: 'Thai', flag: '🇹🇭' },
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
];

export default function LangVocabHub() {
  const [selectedLang, setSelectedLang] = useState(languages[0]);
  const [vocabList, setVocabList] = useState<VocabItem[]>([
    { id: 1, word: 'สวัสดี', translation: 'Hello', language: 'th', example: 'สวัสดีครับ' },
    { id: 2, word: 'ขอบคุณ', translation: 'Thank you', language: 'th', example: 'ขอบคุณมาก' },
  ]);
  const [newWord, setNewWord] = useState('');
  const [newTranslation, setNewTranslation] = useState('');
  const [newExample, setNewExample] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredVocab = vocabList.filter(item => 
    item.language === selectedLang.code && 
    (item.word.toLowerCase().includes(searchTerm.toLowerCase()) || 
     item.translation.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const addVocab = () => {
    if (newWord.trim() && newTranslation.trim()) {
      const newItem: VocabItem = {
        id: Date.now(),
        word: newWord.trim(),
        translation: newTranslation.trim(),
        language: selectedLang.code,
        example: newExample.trim() || undefined,
      };
      setVocabList([...vocabList, newItem]);
      setNewWord('');
      setNewTranslation('');
      setNewExample('');
    }
  };

  const deleteVocab = (id: number) => {
    setVocabList(vocabList.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-50">
      {/* Header */}
      <header className="border-b bg-white dark:bg-zinc-900 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-500 rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-inner">👜</div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Pocket LangHub</h1>
              <p className="text-sm text-zinc-500">Pocket-sized vocab mastery for any language</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-sm px-4 py-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center gap-2">
              👤 Guest Mode
            </div>
            <button className="px-5 py-2 bg-zinc-900 dark:bg-white dark:text-zinc-900 text-white rounded-xl text-sm font-medium hover:bg-zinc-800 transition-colors">
              Login / Sign Up
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-6 py-8">
        {/* Language Selector */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
            Select Target Language
          </h2>
          <div className="flex flex-wrap gap-3">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setSelectedLang(lang)}
                className={`flex items-center gap-2 px-5 py-3 rounded-2xl border transition-all ${
                  selectedLang.code === lang.code 
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-950' 
                    : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300'
                }`}
              >
                <span className="text-2xl">{lang.flag}</span>
                <span className="font-medium">{lang.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Add New Vocab */}
        <div className="bg-white dark:bg-zinc-900 rounded-3xl p-8 mb-8 border border-zinc-100 dark:border-zinc-800">
          <h3 className="font-semibold text-xl mb-6">Add New Vocabulary ({selectedLang.name})</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Word / Phrase</label>
              <input
                type="text"
                value={newWord}
                onChange={(e) => setNewWord(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950 focus:outline-none focus:border-blue-500"
                placeholder="e.g. สวัสดี"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Translation</label>
              <input
                type="text"
                value={newTranslation}
                onChange={(e) => setNewTranslation(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950 focus:outline-none focus:border-blue-500"
                placeholder="e.g. Hello"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Example (optional)</label>
              <input
                type="text"
                value={newExample}
                onChange={(e) => setNewExample(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950 focus:outline-none focus:border-blue-500"
                placeholder="e.g. สวัสดีครับ"
              />
            </div>
          </div>
          <button
            onClick={addVocab}
            className="mt-6 w-full md:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-medium transition-colors flex items-center justify-center gap-2"
          >
            ➕ Add to My Vocab
          </button>
          <p className="text-xs text-zinc-500 mt-3">💡 In future phases, integrate Google Translate here for auto-translation</p>
        </div>

        {/* Vocab List */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="font-semibold text-2xl">My Vocabulary • {selectedLang.name}</h3>
              <p className="text-zinc-500">{filteredVocab.length} words saved</p>
            </div>
            <div className="relative w-80">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search vocab..."
                className="w-full pl-12 pr-4 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-950"
              />
              <span className="absolute left-5 top-4 text-zinc-400">🔍</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredVocab.length > 0 ? (
              filteredVocab.map((item) => (
                <div key={item.id} className="bg-white dark:bg-zinc-900 p-6 rounded-3xl border border-zinc-100 dark:border-zinc-800 group hover:shadow-md transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-3xl font-semibold mb-1">{item.word}</div>
                      <div className="text-xl text-blue-600 dark:text-blue-400">{item.translation}</div>
                    </div>
                    <button 
                      onClick={() => deleteVocab(item.id)}
                      className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-600 transition-all"
                    >
                      🗑️
                    </button>
                  </div>
                  {item.example && (
                    <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-800 text-sm text-zinc-500 italic">
                      "{item.example}"
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-20 text-zinc-400">
                No vocabulary yet for this language. Add some above!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t mt-20 py-12 bg-white dark:bg-zinc-900">
        <div className="max-w-5xl mx-auto px-6 text-center text-sm text-zinc-500">
          Phase 1: Pocket LangHub UI • Multi-lang vocab with personal lists
        </div>
      </footer>
    </div>
  );
}
